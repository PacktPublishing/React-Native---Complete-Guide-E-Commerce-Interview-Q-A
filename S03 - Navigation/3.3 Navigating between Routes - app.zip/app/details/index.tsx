import { Link } from "expo-router";
import { Text, View } from "react-native";

export default function Index() {
  return (
    <View
      style={{
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text>Details File</Text>
      {/* <Link href={`/details/test`}>{`Go to details 2`}</Link> */}
      <Link href="/">{`Back To Home`}</Link>
      
    </View>
  );
}
