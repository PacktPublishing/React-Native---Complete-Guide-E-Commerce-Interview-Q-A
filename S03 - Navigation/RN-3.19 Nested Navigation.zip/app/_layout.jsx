import { Stack } from "expo-router"
import { GestureHandlerRootView } from "react-native-gesture-handler"
import {Drawer} from "expo-router/drawer";
import FontAwesome from "@expo/vector-icons/FontAwesome";

export default RootLayout = () => {

    return (
        <GestureHandlerRootView>
            <Drawer
                screenOptions={{
                    drawerLabelStyle:{
                        fontWeight:'bold',
                        fontSize: 18
                    },
                    drawerPosition:"right"
                }}
            >
                <Drawer.Screen
                    name="(tabs)"
                    options={{
                        title:"Home",
                        drawerIcon:({color})=>
                            <FontAwesome name="home" color={color} size={18}/> 
                         
                    }}
                ></Drawer.Screen>
                <Drawer.Screen
                    name="profile"
                    options={{
                        title:"Profile",
                        drawerIcon:({color})=>
                            <FontAwesome name="user" color={color} size={18}/>  
                    }}
                ></Drawer.Screen>

            </Drawer>
        </GestureHandlerRootView>
    )
}