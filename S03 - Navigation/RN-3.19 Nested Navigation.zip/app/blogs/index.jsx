import { Link } from "expo-router"
import { StyleSheet, Text, View } from "react-native"

export default Blogs = () => {
    return(
        <View style={styles.container}>
            <Text>{`Blogs Tab`}</Text>
            <Link href="/blogs/login">{`Login`}</Link>
        </View>
    )
}

const styles=StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#fff',
        alignItems:'center',
        justifyContent:'center'
    }
})