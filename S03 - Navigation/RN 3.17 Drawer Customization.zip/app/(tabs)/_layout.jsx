import { Tabs } from "expo-router";
import FontAwesome from "@expo/vector-icons/FontAwesome"

export default function TabLayout() {

    return (
        <Tabs 
            screenOptions={{tabBarActiveTintColor:'green'}}
        >
            <Tabs.Screen
                name="index"
                options={{
                    title:'Home',
                    tabBarIcon:({color})=>
                        <FontAwesome name="home" size={26} color={color}/>
                }}
            ></Tabs.Screen>
            <Tabs.Screen
                name="settings"
                options={{
                    title:'Settings',
                    tabBarActiveBackgroundColor:'gray',
                    tabBarActiveTintColor:'white',
                    tabBarIcon:({color})=>
                        <FontAwesome name="gear" size={26} color={color}/>
                }}
            ></Tabs.Screen>
            <Tabs.Screen
                name="details"
                options={{
                    title:'Details',
                    tabBarLabel:'Custom Label',
                    href:null,
                    tabBarIcon:({color})=>
                        <FontAwesome name="file" size={26} color={color}/>
                }}
            ></Tabs.Screen>

        </Tabs>
    )
}