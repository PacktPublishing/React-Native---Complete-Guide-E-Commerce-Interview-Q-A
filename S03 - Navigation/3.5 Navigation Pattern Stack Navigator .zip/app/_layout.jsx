import { Stack } from "expo-router";
import { Button } from "react-native";

export default function RootLayout() {

    return (
        // <Stack/>
        <Stack
            screenOptions={{
                headerStyle: {
                    backgroundColor: '#f4511e',
                },
                headerTintColor: '#fff',
                headerTitleStyle: {
                    fontWeight: 'bold',
                },
            }}>
            <Stack.Screen name="index" options={{
                title: "Home Screen",
            }} />
            <Stack.Screen name="settings" options={{ title: "Settings Screen" }} />
            <Stack.Screen name="details" options={{ title: "Detail Screen" }} />
        </Stack>
    );
}

