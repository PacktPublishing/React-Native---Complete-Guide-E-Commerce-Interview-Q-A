import { Link, useNavigation } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useEffect } from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';

export default function Index() {

  const navigation = useNavigation();

  useEffect(() => {

    navigation.setOptions({
      headerStyle: {
        backgroundColor: 'greenyellow',
      },
      headerTintColor: 'red',
    })
  }, [])

  return (
    <View style={styles.container}>
      <Text>Setting File</Text>
      <StatusBar style="auto" />
      <Link href={`/details`}>{`Go to Details`}</Link>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
