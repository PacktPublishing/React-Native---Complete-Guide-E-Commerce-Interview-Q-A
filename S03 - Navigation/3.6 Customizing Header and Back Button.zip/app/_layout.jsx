import { Stack } from "expo-router";
import { Button } from "react-native";

export default function RootLayout() {

    return (
        // <Stack/>
        <Stack
            screenOptions={({ navigation }) => ({
                headerStyle: {
                    backgroundColor: '#f4511e',
                },
                headerTintColor: '#fff',
                headerTitleStyle: {
                    fontWeight: 'bold',
                },
                headerLeft: () => (
                    <Button
                        title="Back"
                        color="blue"
                        onPress={() => navigation.goBack()}
                    />
                ),
            })}

        >
            <Stack.Screen name="index" options={{
                title: "Home Screen",
                headerLeft: null
            }} />
            <Stack.Screen name="settings" options={{
                title: "Settings Screen",
                //headerLeft: () =><Button title="Back" color={"green"} />
            }} />
            <Stack.Screen name="details" options={({ navigation }) => ({
                title: "Detail Screen",
                headerStyle: {
                    backgroundColor: 'green',
                },
                headerTintColor: 'yellow',
                headerTitleStyle: {
                    fontWeight: 'bold',
                },
                headerLeft: () => (
                    <Button
                        title="Back"
                        color="red"
                        onPress={() => navigation.goBack()}
                    />
                ),
            })} />
        </Stack>
    );
}

