import { launchCameraAsync, useCameraPermissions, PermissionStatus, CameraType, launchImageLibraryAsync } from 'expo-image-picker';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Alert, Button, StyleSheet, Text, View, Image, ScrollView, TextInput } from 'react-native';

export default function App() {
  const [camPermissionInfo, requestPermission] = useCameraPermissions();
  const [imgUri, setImgUri] = useState([]);
  const [selectionLimit, setSelectionLimit] = useState(1);

  const verifyPermissions = async () => {
    if (camPermissionInfo.status === PermissionStatus.UNDETERMINED) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }
    if (camPermissionInfo.status === PermissionStatus.DENIED) {
      Alert.alert('Permissions Absent!', 'You may not be able to use Camera.');
      return false;
    }

    return true;
  }

  const clickImageHandler = async () => {
    const hasPermission = await verifyPermissions();

    if (!hasPermission) {
      return;
    }

    // const image = await launchCameraAsync({
    //   allowsEditing: true,
    //   aspect: [3, 4],
    //   quality: 1,
    //   cameraType: CameraType.back
    // });
    const image = await launchImageLibraryAsync({
      allowsMultipleSelection: true,
      selectionLimit : selectionLimit
    });

    setImgUri(image.assets);
  }

  return (
    <View style={styles.container}>
      <Text style={{fontSize:20}}>
        Set the limit for Image Selection 
      </Text>
      <TextInput 
        style={styles.inp} 
        keyboardType="numeric"
        defaultValue={selectionLimit.toString()}
        onChangeText={(val)=>val&&setSelectionLimit(parseInt(val))}
      />

      <View>
        <Button
          title='Select Image'
          onPress={clickImageHandler}
        />
      </View>
      <ScrollView style={styles.imageContainer}>
        {
          imgUri ? imgUri.map((imgAsset, key)=>(
            <Image style={styles.image} key={key} source={{ uri: imgAsset.uri }} />
          )) 
          : <Text>No Image Taken.</Text>
        }
      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  imageContainer: {
    height:"auto",
    width: "auto",
    padding: 20,
  },
  image: {
    height:320,
    width: 320,
    borderRadius: 10,
    margin: 10
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100
  },
  inp: {
    height: 40,
    width: 70,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    fontSize: 24
  },
});
