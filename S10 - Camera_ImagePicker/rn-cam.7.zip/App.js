import { launchCameraAsync, useCameraPermissions, PermissionStatus, launchImageLibraryAsync } from 'expo-image-picker';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Alert, Button, Image, ScrollView, StyleSheet, Text, View } from 'react-native';

export default function App() {
  const [camPermissionInfo, requestPermission] = useCameraPermissions();
  const [imageUri, setImageUri] = useState([]);

  const verifyPermissions = async () => {
    if (camPermissionInfo.status === PermissionStatus.UNDETERMINED) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }
    if (camPermissionInfo.status === PermissionStatus.DENIED) {
      Alert.alert('Permissions Absent!', 'You may not be able to use Camera.');
      return false;
    }

    return true;
  }

  const clickImageHandler = async () => {
    const hasPermission = await verifyPermissions();

    if (!hasPermission) {
      return;
    }

    const image = await launchImageLibraryAsync();
    setImageUri(image.assets[0].uri);
  }


  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>

      <View>
        <Button
          title='Click Image'
          onPress={clickImageHandler}
        />
      </View>

      <View style={styles.imageContainer}>
        <Image style={styles.image} source={{ uri: imageUri }} />
      </View>

      <StatusBar style="auto" />
    </View>
  );
}
const styles = StyleSheet.create({
  imageContainer: {
    height: 420,
    width: 420,
    padding: 20
  },
  image: {
    height: '100%',
    width: '100%',
    borderRadius: 10,
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});