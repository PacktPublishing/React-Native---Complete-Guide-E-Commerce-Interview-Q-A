import { launchCameraAsync, useCameraPermissions, PermissionStatus, launchImageLibraryAsync } from 'expo-image-picker';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Alert, Button, Image, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';

export default function App() {
  const [camPermissionInfo, requestPermission] = useCameraPermissions();
  const [imageUri, setImageUri] = useState([]);
  const [selectionLimit, setSelectionLimit] = useState(1);

  const verifyPermissions = async () => {
    if (camPermissionInfo.status === PermissionStatus.UNDETERMINED) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }
    if (camPermissionInfo.status === PermissionStatus.DENIED) {
      Alert.alert('Permissions Absent!', 'You may not be able to use Camera.');
      return false;
    }

    return true;
  }

  const clickImageHandler = async () => {
    const hasPermission = await verifyPermissions();

    if (!hasPermission) {
      return;
    }

    const image = await launchImageLibraryAsync({
      allowsMultipleSelection: true,
      selectionLimit: selectionLimit
    });
    setImageUri(image.assets);
  }


  return (
    <View style={styles.container}>
      <Text style={{ fontSize: 20 }}>Set the limit for Image Selection</Text>
      <TextInput keyboardType='numeric' style={styles.inp} onChangeText={(val) => val && setSelectionLimit(parseInt(val))} defaultValue={selectionLimit.toString()} />

      <View>
        <Button
          title='Select Image'
          onPress={clickImageHandler}
        />
      </View>

      <ScrollView style={styles.imageContainer}>
        {imageUri.map((imageAsset, key) => (
          <Image style={styles.image} source={{ uri: imageAsset.uri }} key={key} />
        ))}
      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
  },
  imageContainer: {
    height: "auto",
    width: "auto",
    padding: 20
  },
  image: {
    height: 320,
    width: 320,
    margin: 10,
    borderRadius: 10,
  },
  inp: {
    height: 40,
    width: 70,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    fontSize: 24
  }
});
