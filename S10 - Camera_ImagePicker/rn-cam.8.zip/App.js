import { launchCameraAsync, useCameraPermissions, PermissionStatus, launchImageLibraryAsync } from 'expo-image-picker';
import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { Alert, Button, Image, ScrollView, StyleSheet, Text, View } from 'react-native';

export default function App() {
  const [camPermissionInfo, requestPermission] = useCameraPermissions();
  const [imageUri, setImageUri] = useState([]);

  const verifyPermissions = async () => {
    if (camPermissionInfo.status === PermissionStatus.UNDETERMINED) {
      const permissionResponse = await requestPermission();
      return permissionResponse.granted;
    }
    if (camPermissionInfo.status === PermissionStatus.DENIED) {
      Alert.alert('Permissions Absent!', 'You may not be able to use Camera.');
      return false;
    }

    return true;
  }

  const clickImageHandler = async () => {
    const hasPermission = await verifyPermissions();

    if (!hasPermission) {
      return;
    }

    const image = await launchImageLibraryAsync({
      allowsMultipleSelection: true,
    });
    setImageUri(image.assets);
  }


  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>

      <View>
        <Button
          title='Select Image'
          onPress={clickImageHandler}
        />
      </View>

      <ScrollView style={styles.imageContainer}>
        {imageUri.map((imageAsset, key) => (
          <Image style={styles.image} source={{ uri: imageAsset.uri }} key={key} />
        ))}
      </ScrollView>

      <StatusBar style="auto" />
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 100,
  },
  imageContainer: {
    height: "auto",
    width: "auto",
    padding: 20
  },
  image: {
    height: 320,
    width: 320,
    margin: 10,
    borderRadius: 10,
  }
});
