import { StatusBar } from 'expo-status-bar';
import { Alert, Button, StyleSheet, Text, View } from 'react-native';
import * as Location from "expo-location";

export default function App() {

  async function getCurrentLocationHandler() {
    const { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Permission to access location was denied.");
      return;
    }

    const location = await Location.getCurrentPositionAsync();

    const locationDetails = await Location.reverseGeocodeAsync(location.coords);
    console.log(locationDetails);
  }
  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>
      <Button title='Get Location' onPress={getCurrentLocationHandler} />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
