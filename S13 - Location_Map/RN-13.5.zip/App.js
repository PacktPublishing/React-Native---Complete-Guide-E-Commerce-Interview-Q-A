import { StatusBar } from 'expo-status-bar';
import { Alert, Button, StyleSheet, Text, View } from 'react-native';
import * as Location from "expo-location";
import MapView from 'react-native-maps';

export default function App() {

  async function getCurrentLocationHandler() {
    const { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Permission to access location was denied.");
      return;
    }

    const location = await Location.getCurrentPositionAsync();

    const locationDetails = await Location.reverseGeocodeAsync(location.coords);
    console.log(locationDetails);
  }
  return (
    <View style={styles.container}>
      <MapView style={{ width: "100%", height: "100%" }}></MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
