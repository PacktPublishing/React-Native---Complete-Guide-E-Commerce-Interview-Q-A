import { StatusBar } from 'expo-status-bar';
import { Alert, Button, StyleSheet, Text, View } from 'react-native';
import * as Location from "expo-location";
import MapView, { Marker } from 'react-native-maps';
import { useEffect, useState } from 'react';

export default function App() {
  const [locationData, setLocationData] = useState({});

  async function getCurrentLocationHandler() {
    const { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("Permission to access location was denied.");
      return;
    }

    const location = await Location.getCurrentPositionAsync();

    const locationDetails = await Location.reverseGeocodeAsync(location.coords);
    setLocationData(location.coords);
  }
  console.log(locationData);

  useEffect(() => {
    getCurrentLocationHandler();
  }, [])
  return (
    <View style={styles.container}>
      <MapView
        style={{ width: "100%", height: "100%" }}
        region={{
          latitude: locationData.latitude || 37.78825,
          longitude: locationData.longitude || -122.4324,
          latitudeDelta: 0.0922,
          longitudeDelta: 0.0421
        }}
      >
        <Marker coordinate={{
          latitude: locationData?.latitude || 37.78825,
          longitude: locationData?.longitude || -122.4324
        }} />
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
