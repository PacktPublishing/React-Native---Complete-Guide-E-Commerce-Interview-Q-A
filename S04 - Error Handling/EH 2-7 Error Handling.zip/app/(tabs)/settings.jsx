import { useEffect } from "react";
import { Alert, Button, StyleSheet, Text, View } from "react-native"

export default Settings = () => {

    const errorHandler = (error, isFatal) => {
        if (isFatal) {
            Alert.alert("Unexpected error occurred", `Error: ${error.name} 
                ${error.message}.
                We have reposted this to our team!!
                Please restart the app.`,
                [
                    {
                        text: "Restart"
                    }
                ])
        }else{
            console.log("Non fatal error", error);
        }

    }

    const throwError = () => {
        throw new Error("Testing Error Utils Global handler.")
    }

    useEffect(()=>{
        ErrorUtils.setGlobalHandler(errorHandler);
    },[])

    return (
        <View style={styles.container}>
            <Text>{`Settings Tab`}</Text>
            <Button title="Throw Error" onPress={throwError}></Button>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    }
})