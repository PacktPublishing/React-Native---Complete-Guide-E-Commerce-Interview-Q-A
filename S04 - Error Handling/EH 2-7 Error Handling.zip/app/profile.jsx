import { useEffect, useState } from "react";
import { StyleSheet, Text, View } from "react-native"
import ErrorBoundary from "../ErrorBoundary";

export default Profile = () => {

    const [error,setError] = useState('');
    function addition(num1,num2){
        return num1-num2;
    }
    const fetchData = () => {
        try{
           console.log(data); 
        }
        catch(ex){
            setError(ex.toString());
        }finally{
            //this code will be executed everytime.
        }
        
    }
    useEffect(()=>{
        fetchData();
    },[])
    
    return(
        <ErrorBoundary>
            <View style={styles.container}>
                <Text>{`Addition is - ${addition(10,2)}`}</Text>
                {error!=='' && <Text style={{color:'red'}}>
                    {error}
                    </Text>}

                {/* <FaultyComponent/> */}
            </View>
        </ErrorBoundary>
    )
}

const styles=StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'#fff',
        alignItems:'center',
        justifyContent:'flex-start'
    }
})

export const FaultyComponent = () => {

    useEffect(()=>{
        throw new Error("Faulty Component Error");
    },[])

    return (
        <View>
            <Text>{`Child Component`}</Text>
        </View>
    )
}

