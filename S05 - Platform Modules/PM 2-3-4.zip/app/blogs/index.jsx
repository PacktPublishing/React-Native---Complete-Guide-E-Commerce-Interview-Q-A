import { Link } from "expo-router"
import { useState } from "react"
import { Button, StyleSheet, Text, View } from "react-native"

export default Blogs = () => {

    const [error, setError] = useState(null);
    const [result, setResult] = useState([]);

    const getData = async () => {

        try {
            const response = await fetch("https://jsonplaceholder.typicode.com/posts");
            if (!response.ok) {
                throw new Error(`Server Error : ${response.status}`);
            } 
            let data = await response.json();
            data = {};
            if(!Array.isArray(data)){
                throw new Error("Invalid Data format - Expected an array");
            }
            setResult(data);
            setError(null);
            return data;
        }
        catch (error) {
            setError(error.message);
            console.error("Error fetching posts - ", error.message);
        }
    }

    return (
        error ?
            <View>
                <Text style={{color:"red"}}>{error}</Text>
            </View> :
            <View style={styles.container}>
                <Text>{`Blogs Tab`}</Text>
                <Link href="/blogs/login">{`Login`}</Link>
                <Button title="Get Data" onPress={() => getData()}></Button>
                {result.map((item)=> <Text key={item.id}>{item.title}</Text>)}
            </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center'
    }
})