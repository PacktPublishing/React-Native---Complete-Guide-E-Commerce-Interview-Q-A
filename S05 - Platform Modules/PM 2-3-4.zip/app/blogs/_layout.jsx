import { Stack } from "expo-router"

export default Layout = () => {

    return (
        <Stack>
            <Stack.Screen 
                name="index"
                options={{title:"Blogs"}}
            ></Stack.Screen>
             <Stack.Screen 
                name="login"
                options={{title:"Login"}}
            ></Stack.Screen>
        </Stack>
    )
}