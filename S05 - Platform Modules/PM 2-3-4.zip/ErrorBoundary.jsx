import React from "react";
import { Text, View } from "react-native";

class ErrorBoundary extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            hasError: false
        }
    }
    
    static getDerivedStateFromError(error) {
        return {hasError:true}
    }

    render(){
        if(this.state.hasError){
            return (
                <View>
                    <Text>{`Something went wrong in the component`}</Text>
                </View>
            )
        }

        return this.props.children
    }
}

export default ErrorBoundary;