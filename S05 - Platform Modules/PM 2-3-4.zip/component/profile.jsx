import { StyleSheet, Text, View, Platform } from "react-native"

export default Profile = () => {
    return(
            <View style={styles.container}>
                <Text style={styles.text}>{`Application is running on ${Platform.OS}`}</Text>
            </View>
    )
}

const styles=StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:'lightgreen',
        alignItems:'center',
        justifyContent:'flex-start'
    },
    text:{
        fontSize:Platform.OS === "android"? 20:40,
        ...Platform.select({
            ios: {color:"red"},
            android:{color:"green"},
            default:{color:"blue"}
        })
    }
})
