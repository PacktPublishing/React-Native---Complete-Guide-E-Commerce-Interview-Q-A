import { Stack } from "expo-router"
import { ProductProvider } from "../components/ProductContext";
import { UserProvider } from "../components/UserContext";
import { StripeProvider } from "@stripe/stripe-react-native";

export default RootLayout = () => {
    return (
        <UserProvider>
            <ProductProvider>
                <StripeProvider publishableKey={process.env.EXPO_PUBLIC_STRIPE_PUBLISHABLE_KEY}>
                    <Stack>
                        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                        <Stack.Screen
                            name="product/[id]"
                            options={{ title: "Product Details", headerBackTitle: "Back" }}
                        />
                    </Stack>
                </StripeProvider>
            </ProductProvider>
        </UserProvider>
    );
}