import { StatusBar } from 'expo-status-bar';
import { Alert, Button, Platform, StyleSheet, Text, View } from 'react-native';
import * as Notifications from "expo-notifications";
import { useEffect, useState } from 'react';
import Constants from "expo-constants";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  })
});

export default function App() {
  const [expoPushToken, setExpoPushToken] = useState("");

  async function configurePushNotifications() {
    const existingStatus = Notifications.getPermissionsAsync();
    let finalStatus = existingStatus.status;
    if (existingStatus.status !== "granted") {
      const newStatus = await Notifications.requestPermissionsAsync();
      finalStatus = newStatus.status;
    }
    if (finalStatus !== "granted") {
      Alert.alert("Notification Permission is Required.");
      return;
    }
    if (Platform.OS === "android") {
      Notifications.setNotificationChannelAsync("default", {
        name: "default",
        importance: Notifications.AndroidImportance.DEFAULT,
      })
    }
    const projectId = Constants?.expoConfig?.extra?.eas?.projectId;
    const pushTokenValue = await Notifications.getExpoPushTokenAsync({
      projectId
    });
    setExpoPushToken(pushTokenValue.data);
  }

  async function sendPushNotificationHandler() {
    try {
      const response = await fetch("https://exp.host/--/api/v2/push/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          to: expoPushToken,
          title: "Hello World!",
          body: "This is a test notification"
        })
      })
      console.log(response);
    } catch (error) {
      console.log(error);
    }
  }
  useEffect(() => {
    configurePushNotifications();
    const notificationListener = Notifications.addNotificationReceivedListener((notification) => {
      console.log(notification);
    });

    const responseNotificationListener = Notifications.addNotificationResponseReceivedListener((notification) => {
      console.log(notification);
    })

    return () => {
      notificationListener.remove();
      responseNotificationListener.remove();
    }
  }, [])
  function scheduleNotificationHandler() {
    Notifications.scheduleNotificationAsync({
      content: {
        title: "Hello World!",
        body: "This is a test notification."
      },
      trigger: {
        seconds: 5,
        type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      }
    });
  }
  return (
    <View style={styles.container}>
      <Button title="Schedule Notification" onPress={scheduleNotificationHandler} />
      <Button title="Send Push Notification" onPress={sendPushNotificationHandler} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
});
