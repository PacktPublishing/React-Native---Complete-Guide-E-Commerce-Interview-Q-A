import { Image, Text, View } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useProductContext } from "../../components/ProductContext"
import Constants from "expo-constants"
import { FontAwesome } from "@expo/vector-icons";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const Cart = () => {
    const { cartItems } = useProductContext();
    return (
        <SafeAreaView className="flex-1 bg-white p-8">
            <Text className="text-3xl font-semibold mb-4">Cart</Text>
            {cartItems.map((product) => (
                <View className="border-b border-gray-300 py-4 flex-row gap-5" key={product.id}>
                    <Image
                        source={{ uri: `${BASE_URL}${product?.image}` }}
                        className="w-32 h-32"
                        resizeMode="cover"
                    />
                    <View className="flex-1">
                        <View className="flex-row justify-between">
                            <Text className="text-xl font-semibold">{product?.name}</Text>
                            <Text className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-xs font-medium">
                                {product?.productType?.name}
                            </Text>
                        </View>
                        <View className="flex-row gap-1 items-center">
                            {[...Array(product?.rating)].map((_, index) => (
                                <FontAwesome name="star" size={16} color="#FFD700" key={index} />
                            ))}
                        </View>
                        <View className="flex-row gap-x-2 items-center mt-2">
                            <Text className="text-xl font-semibold">${product?.sellPrice}</Text>
                            <Text className="text-gray-500 line-through font-medium text-sm">${product?.mrp}</Text>
                        </View>
                    </View>
                </View>
            ))}
        </SafeAreaView>
    );
}

export default Cart