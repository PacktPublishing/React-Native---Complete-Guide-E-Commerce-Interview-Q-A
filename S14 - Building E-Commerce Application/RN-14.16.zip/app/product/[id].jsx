import { useLocalSearchParams } from "expo-router";
import { Text, View } from "react-native"
import Constants from "expo-constants";
import { useEffect } from "react";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const ProductDetails = () => {
    const { id } = useLocalSearchParams();

    const fetchProductDetails = () => {
        fetch(`${BASE_URL}/api/products/${id}`)
            .then((response) => response.json())
            .then((data) => console.log(data))
            .catch((error) => console.log(error));
    }

    useEffect(() => {
        fetchProductDetails();
    }, [])
    return (
        <View>
            <Text>Product Details: {id}</Text>
        </View>
    )
}

export default ProductDetails;