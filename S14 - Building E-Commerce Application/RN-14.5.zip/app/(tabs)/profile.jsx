import { Text, View } from "react-native"

const Profile = () => {
    return (
        <View>
            <Text>Profile Tab</Text>
        </View>
    )
}

export default Profile 