import { Stack } from "expo-router"

export default RootLayout = () => {
    return (
        <Stack />
    )
}