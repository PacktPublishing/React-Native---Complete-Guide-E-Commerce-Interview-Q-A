import { Image, Text, View } from "react-native"
import Constants from "expo-constants";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const ProductCard = ({ product }) => {
    return (
        <View className="w-1/2">
            <Image source={{ uri: `${BASE_URL}${product?.image}` }} className="w-full h-52" />
            <View className="p-8">
                <Text className="text-lg font-semibold">{product?.name}</Text>
                <Text className="text-sm text-gray-400">{product?.description}</Text>
                <View className="flex-row gap-x-3 mt-3 items-center">
                    <Text className="text-lg font-semibold">${product?.sellPrice}</Text>
                    <Text className="text-sm text-gray-500 line-through">${product?.mrp}</Text>
                </View>
            </View>
        </View>
    )
}

export default ProductCard;