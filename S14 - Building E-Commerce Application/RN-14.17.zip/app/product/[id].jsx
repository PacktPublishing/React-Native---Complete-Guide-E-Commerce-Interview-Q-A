import { useLocalSearchParams } from "expo-router";
import { Image, Text, View } from "react-native"
import Constants from "expo-constants";
import { useEffect, useState } from "react";
import { FontAwesome } from "@expo/vector-icons";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const ProductDetails = () => {
    const { id } = useLocalSearchParams();
    const [product, setProduct] = useState({});

    const fetchProductDetails = () => {
        fetch(`${BASE_URL}/api/products/${id}`)
            .then((response) => response.json())
            .then((data) => setProduct(data.data))
            .catch((error) => console.log(error));
    }

    useEffect(() => {
        fetchProductDetails();
    }, [])
    return (
        <View className="flex-1 bg-white p-10">
            <Image
                source={{ uri: `${BASE_URL}${product?.image}` }}
                className="w-full h-60"
                resizeMode="contain"
            />
            <View className="p-5">
                <View className="flex-row justify-end">
                    <Text className="text-xs font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                        {product?.productType?.name}
                    </Text>
                </View>
                <Text className="text-2xl font-semibold my-2">{product?.name}</Text>
                <View className="flex-row gap-1 items-center">
                    {[...Array(product?.rating)].map((_, index) => (
                        <FontAwesome name="star" size={16} color="#FFD700" key={index} />
                    ))}
                </View>
                <View className="my-5 flex-col gap-2">
                    <Text className="text-sm font-medium text-green-600">Special Price</Text>
                    <View className="flex-row gap-x-3 items-center">
                        <Text className="text-lg font-semibold">${product?.sellPrice}</Text>
                        <Text className="text-sm text-gray-500 line-through">${product?.mrp}</Text>
                    </View>
                    <Text className="text-gray-500 font-medium">{product?.currentStock} items left</Text>
                </View>
            </View>
        </View>
    );
}

export default ProductDetails;