import { Tabs } from "expo-router";
import { FontAwesome } from "@expo/vector-icons"
import { useProductContext } from "../../components/ProductContext";
import { Text, View } from "react-native";

export default function TabLayout() {
    const { cartItems } = useProductContext();
    const isLoggedIn = false;
    return (
        <Tabs>
            <Tabs.Screen name="index" options={{
                title: "Home",
                headerShown: false,
                tabBarIcon: ({ color }) => <FontAwesome name="home" size={26} color={color} />
            }} />
            <Tabs.Screen name="cart" options={{
                title: "Cart",
                headerShown: false,
                tabBarIcon: ({ color }) =>
                    <View className="relative">
                        <View className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-red-500 flex justify-center items-center z-10">
                            <Text className="text-white text-sm font-semibold">{cartItems.length}</Text>
                        </View>
                        <FontAwesome name="shopping-cart" size={26} color={color} />
                    </View>
            }} />
            <Tabs.Screen name="profile" options={{
                title: "Profile",
                headerShown: false,
                tabBarItemStyle: {
                    display: isLoggedIn ? "flex" : "none"
                },
                tabBarIcon: ({ color }) => <FontAwesome name="user" size={26} color={color} />
            }} />
            <Tabs.Screen name="login" options={{
                title: "Login",
                headerShown: false,
                tabBarItemStyle: {
                    display: isLoggedIn ? "none" : "flex"
                },
                tabBarIcon: ({ color }) => <FontAwesome name="user" size={26} color={color} />
            }} />
            <Tabs.Screen name="register" options={{
                title: "Register",
                headerShown: false,
                tabBarIcon: ({ color }) => <FontAwesome name="user" size={26} color={color} />,
                tabBarItemStyle: {
                    display: "none",
                }
            }} />
        </Tabs>
    )
}