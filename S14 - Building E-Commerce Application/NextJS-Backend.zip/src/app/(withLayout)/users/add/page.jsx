import AddUser from "@/screens/admin/users/add";

const AddUserPage = ({ searchParams }) => {
  return <AddUser searchParams={searchParams} />;
};

export default AddUserPage;
