import AddProductType from "@/screens/admin/product-type/add";

const AddProductTypePage = ({ searchParams }) => {
  return <AddProductType searchParams={searchParams} />;
};

export default AddProductTypePage;
