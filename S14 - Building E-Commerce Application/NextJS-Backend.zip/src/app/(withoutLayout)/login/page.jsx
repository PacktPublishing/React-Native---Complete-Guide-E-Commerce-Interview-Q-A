import Login from "@/screens/authentication/login";

const LoginPage = ({ searchParams }) => {
  return <Login searchParams={searchParams} />;
};

export default LoginPage;
