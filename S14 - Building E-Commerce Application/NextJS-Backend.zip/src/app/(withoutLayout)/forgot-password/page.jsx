import ForgotPassword from "@/screens/authentication/forgot-password";

const ForgotPasswordPage = () => {
  return (
    <>
      <ForgotPassword />
    </>
  );
};

export default ForgotPasswordPage;
