import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import "../globals.css"
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import Constants from "expo-constants";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

export default function App() {
  const [products, setProducts] = useState([]);
  const fetchProductData = () => {
    fetch(`${BASE_URL}/api/products`)
      .then((response) => response.json())
      .then((data) => setProducts(data.data))
      .catch((error) => console.log(error));
  }

  console.log(products);

  useEffect(() => {
    fetchProductData();
  }, [])
  return (
    <SafeAreaView className="min-h-screen">
      <View className="bg-white flex-1">
        <Text>Open up App.js to start working on your app!</Text>
      </View>
    </SafeAreaView>
  );
}
