import { FlatList, Text, TextInput, TouchableOpacity, View } from 'react-native';
import "../globals.css"
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import Constants from "expo-constants";
import ProductCard from '../../components/ProductCard';
import { FontAwesome } from "@expo/vector-icons";
import FilterModal from '../../components/FilterModal';

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

export default function App() {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({
    search: ""
  });
  const [openFilterModal, setOpenFilterModal] = useState(false);

  const toggleFilterModal = () => {
    setOpenFilterModal(!openFilterModal);
  }

  const fetchProductData = () => {
    fetch(`${BASE_URL}/api/products?search=${filters.search}`)
      .then((response) => response.json())
      .then((data) => setProducts(data.data))
      .catch((error) => console.log(error));
  }

  useEffect(() => {
    fetchProductData();
  }, [filters]);

  return (
    <SafeAreaView className="min-h-screen">
      <View className="bg-white flex-1 pb-10">
        <View className="flex-row gap-2 items-center">
          <View className="p-2 relative w-10/12">
            <FontAwesome name="search" size={16} color="gray" className="absolute top-4 left-4" />
            <TextInput
              className="px-4 py-2 border border-gray-300 rounded-md pl-8"
              placeholder="Search..."
              onChangeText={(text) => setFilters({ search: text })}
            />
          </View>
          <TouchableOpacity className="border border-blue-500 rounded-md py-1 px-3" onPress={toggleFilterModal}>
            <Text className="text-center text-lg font-semibold text-blue-500">Filter</Text>
          </TouchableOpacity>
        </View>
        {products.length > 0 ? (
          <FlatList
            data={products}
            numColumns={2}
            renderItem={({ item }) => <ProductCard product={item} />}
            keyExtractor={(item) => item.id}
          />
        ) : (
          <View className="flex-1 items-center justify-center">
            <Text className="text-lg font-semibold">No products found.</Text>
          </View>
        )}
      </View>
      <FilterModal openFilterModal={openFilterModal} toggleFilterModal={toggleFilterModal} />
    </SafeAreaView>
  );
}
