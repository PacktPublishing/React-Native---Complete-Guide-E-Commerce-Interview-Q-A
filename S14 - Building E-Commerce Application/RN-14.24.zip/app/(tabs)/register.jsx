import { Text, TextInput, TouchableOpacity, View } from "react-native"

const Register = () => {
    return (
        <View className="flex-1 bg-white py-20">
            <Text className="text-4xl font-medium text-center">Sign Up</Text>
            <View className="w-full max-w-sm mx-auto">
                <View className="flex-col gap-6">
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Name</Text>
                        <TextInput
                            placeholder="Enter your Name"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                        />
                    </View>
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Email</Text>
                        <TextInput
                            placeholder="Enter your Email"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                            autoCapitalize="none"
                        />
                    </View>
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Password</Text>
                        <TextInput
                            placeholder="Enter your Password"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                            secureTextEntry
                        />
                    </View>
                    <TouchableOpacity className="bg-blue-600 rounded-lg py-3">
                        <Text className="text-white text-center font-semibold">
                            Submit
                        </Text>
                    </TouchableOpacity>
                    <Text className="text-center font-medium">
                        Already have an account? <Text className="text-blue-600 font-semibold">Login</Text>
                    </Text>
                </View>
            </View>
        </View>
    )
}

export default Register;