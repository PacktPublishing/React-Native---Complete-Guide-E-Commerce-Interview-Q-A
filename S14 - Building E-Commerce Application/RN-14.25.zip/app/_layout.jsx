import { Stack } from "expo-router"
import { ProductProvider } from "../components/ProductContext";

export default RootLayout = () => {
    return (
        <ProductProvider>
            <Stack>
                <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                <Stack.Screen
                    name="product/[id]"
                    options={{ title: "Product Details", headerBackTitle: "Back" }}
                />
            </Stack>
        </ProductProvider>
    );
}