import { FlatList, Text, TextInput, View } from 'react-native';
import "../globals.css"
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import Constants from "expo-constants";
import ProductCard from '../../components/ProductCard';
import { FontAwesome } from "@expo/vector-icons";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

export default function App() {
  const [products, setProducts] = useState([]);
  const [filters, setFilters] = useState({
    search: ""
  });
  const fetchProductData = () => {
    fetch(`${BASE_URL}/api/products?search=${filters.search}`)
      .then((response) => response.json())
      .then((data) => setProducts(data.data))
      .catch((error) => console.log(error));
  }

  useEffect(() => {
    fetchProductData();
  }, [filters]);

  console.log(filters);
  return (
    <SafeAreaView className="min-h-screen">
      <View className="bg-white flex-1 pb-10">
        <View className="p-2 relative">
          <FontAwesome name="search" size={16} color="gray" className="absolute top-4 left-4" />
          <TextInput
            className="px-4 py-2 border border-gray-300 rounded-md pl-8"
            placeholder="Search..."
            onChangeText={(text) => setFilters({ search: text })}
          />
        </View>
        {products.length > 0 ? (
          <FlatList
            data={products}
            numColumns={2}
            renderItem={({ item }) => <ProductCard product={item} />}
            keyExtractor={(item) => item.id}
          />
        ) : (
          <View className="flex-1 items-center justify-center">
            <Text className="text-lg font-semibold">No products found.</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}
