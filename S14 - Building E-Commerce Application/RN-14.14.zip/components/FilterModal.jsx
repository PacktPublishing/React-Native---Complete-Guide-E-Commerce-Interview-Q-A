import { Modal, Pressable, Text, TouchableOpacity, View } from "react-native";
import Constants from "expo-constants";
import { useEffect, useState } from "react";
import { cn } from "../lib/utils";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const SortingOptions = [
    { value: "all", label: "All" },
    { value: "-sellPrice", label: "Price high to low" },
    { value: "sellPrice", label: "Price low to high" },
];

const RatingOptions = [
    { value: "all", label: "all" },
    { value: "1", label: "1" },
    { value: "2", label: "2" },
    { value: "3", label: "3" },
    { value: "4", label: "4" },
    { value: "5", label: "5" },
];

const AvailabilityOptions = [
    { value: "all", label: "All" },
    { value: "true", label: "In Stock" },
    { value: "false", label: "Out of Stock" },
]
const FilterModal = ({ openFilterModal, toggleFilterModal }) => {
    const [productTypes, setProductTypes] = useState([]);
    const [filters, setFilters] = useState({
        productTypeId: "all",
        sortBy: "all",
        rating: "all",
        inStock: "all"
    });

    const handleFilterChange = (filterName, value) => {
        setFilters((prev) => ({
            ...prev,
            [filterName]: value
        }));
    }

    const fetchProductTypes = () => {
        fetch(`${BASE_URL}/api/products/product-type`)
            .then((response) => response.json())
            .then((data) => {
                const modifiedData = data.data.map((item) => ({
                    label: item.name,
                    value: item.id
                }));
                setProductTypes([{ value: "all", label: "All" }, ...modifiedData]);
            })
            .catch((error) => console.log(error))
    }

    useEffect(() => {
        fetchProductTypes();
    }, []);

    return (
        <Modal
            visible={openFilterModal}
            transparent={true}
            animationType="slide"
            onRequestClose={toggleFilterModal}
        >
            <View className="h-full w-full bg-white p-10 mt-16 shadow-lg">
                <Text className="text-2xl font-semibold text-center my-4">
                    Filters
                </Text>
                <View className="mb-4">
                    <Text className="text-xl font-semibold my-4">Category</Text>
                    <View className="flex-row flex-wrap gap-3">
                        {productTypes.map((option, index) => (
                            <Pressable
                                className={cn("border border-gray-300 rounded-lg py-2 px-4",
                                    filters.productTypeId === option.value && "bg-blue-500 border-blue-500"
                                )}
                                key={index}
                                onPress={() => handleFilterChange("productTypeId", option.value)}
                            >
                                <Text className={cn(filters.productTypeId === option.value && "text-white font-medium")}>{option.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                </View>
                <View className="mb-4">
                    <Text className="text-xl font-semibold my-4">Sort By</Text>
                    <View className="flex-row flex-wrap gap-3">
                        {SortingOptions.map((option, index) => (
                            <Pressable
                                className={cn("border border-gray-300 rounded-lg py-2 px-4",
                                    filters.sortBy === option.value && "bg-blue-500 border-blue-500"
                                )}
                                key={index}
                                onPress={() => handleFilterChange("sortBy", option.value)}
                            >
                                <Text className={cn(filters.sortBy === option.value && "text-white font-medium")}>{option.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                </View>
                <View className="mb-4">
                    <Text className="text-xl font-semibold my-4">Rating</Text>
                    <View className="flex-row flex-wrap gap-3">
                        {RatingOptions.map((option, index) => (
                            <Pressable
                                className={cn("border border-gray-300 rounded-lg py-2 px-4",
                                    filters.rating === option.value && "bg-blue-500 border-blue-500"
                                )}
                                key={index}
                                onPress={() => handleFilterChange("rating", option.value)}
                            >
                                <Text className={cn(filters.rating === option.value && "text-white font-medium")}>{option.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                </View>
                <View className="mb-4">
                    <Text className="text-xl font-semibold my-4">Availability</Text>
                    <View className="flex-row flex-wrap gap-3">
                        {AvailabilityOptions.map((option, index) => (
                            <Pressable
                                className={cn("border border-gray-300 rounded-lg py-2 px-4",
                                    filters.inStock === option.value && "bg-blue-500 border-blue-500"
                                )}
                                key={index}
                                onPress={() => handleFilterChange("inStock", option.value)}
                            >
                                <Text className={cn(filters.inStock === option.value && "text-white font-medium")}>{option.label}</Text>
                            </Pressable>
                        ))}
                    </View>
                </View>
                <TouchableOpacity
                    className="border border-blue-500 rounded-md py-1 px-3"
                    onPress={toggleFilterModal}
                >
                    <Text className="text-center text-lg font-semibold text-blue-500">
                        Close
                    </Text>
                </TouchableOpacity>
            </View>
        </Modal>
    );
}

export default FilterModal;