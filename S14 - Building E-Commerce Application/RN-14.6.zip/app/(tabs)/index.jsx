import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import "../globals.css"
import { SafeAreaView } from 'react-native-safe-area-context';

export default function App() {
  return (
    <SafeAreaView className="min-h-screen">
      <View className="bg-white flex-1">
        <Text>Open up App.js to start working on your app!</Text>
      </View>
    </SafeAreaView>
  );
}
