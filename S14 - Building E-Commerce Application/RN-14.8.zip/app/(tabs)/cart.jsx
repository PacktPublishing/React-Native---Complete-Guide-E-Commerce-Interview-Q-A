import { Text, View } from "react-native"

const Cart = () => {
    return (
        <View>
            <Text>Cart Tab</Text>
        </View>
    )
}

export default Cart