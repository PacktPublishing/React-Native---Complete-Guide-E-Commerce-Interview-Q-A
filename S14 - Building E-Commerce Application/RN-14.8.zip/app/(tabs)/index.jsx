import { Text, View } from 'react-native';
import "../globals.css"
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import Constants from "expo-constants";
import ProductCard from '../../components/ProductCard';

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

export default function App() {
  const [products, setProducts] = useState([]);
  const fetchProductData = () => {
    fetch(`${BASE_URL}/api/products`)
      .then((response) => response.json())
      .then((data) => setProducts(data.data))
      .catch((error) => console.log(error));
  }

  useEffect(() => {
    fetchProductData();
  }, [])
  return (
    <SafeAreaView className="min-h-screen">
      <View className="bg-white flex-1">
        <ProductCard product={products[0]} />
      </View>
    </SafeAreaView>
  );
}
