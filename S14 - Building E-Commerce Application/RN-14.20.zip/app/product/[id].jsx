import { useLocalSearchParams } from "expo-router";
import { ActivityIndicator, Image, Pressable, Text, TouchableOpacity, View } from "react-native"
import Constants from "expo-constants";
import { useEffect, useState } from "react";
import { FontAwesome } from "@expo/vector-icons";
import { cn } from "../../lib/utils";
import { useProductContext } from "../../components/ProductContext";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const ProductDetails = () => {
    const { id } = useLocalSearchParams();
    const { addProductToCart, removeProductFromCart, cartItems } = useProductContext();
    const [product, setProduct] = useState();
    const [selectedSize, setSelectedSize] = useState("smallSize");
    const [loading, setLoading] = useState(true);

    const isProductInCart = cartItems.some((item) => item.id === product.id);

    const sizeOptions = [
        { label: "S", value: "smallSize" },
        { label: "M", value: "mediumSize" },
        { label: "L", value: "largeSize" },
    ]

    const fetchProductDetails = () => {
        fetch(`${BASE_URL}/api/products/${id}`)
            .then((response) => response.json())
            .then((data) => setProduct(data.data))
            .catch((error) => console.log(error))
            .finally(() => setLoading(false));
    }

    useEffect(() => {
        fetchProductDetails();
    }, []);

    const handleCartItems = () => {
        if (isProductInCart) {
            removeProductFromCart(product.id)
        } else {
            addProductToCart({
                ...product,
                quantity: 1,
                size: selectedSize
            })
        }
    }

    if (loading) {
        return (
            <View className="flex-1 items-center justify-center">
                <ActivityIndicator size="large" />
            </View>
        )
    }
    return (
        <View className="flex-1 bg-white p-10">
            <Image
                source={{ uri: `${BASE_URL}${product?.image}` }}
                className="w-full h-60"
                resizeMode="contain"
            />
            <View className="p-5">
                <View className="flex-row justify-end">
                    <Text className="text-xs font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                        {product?.productType?.name}
                    </Text>
                </View>
                <Text className="text-2xl font-semibold my-2">{product?.name}</Text>
                <View className="flex-row gap-1 items-center">
                    {[...Array(product?.rating)].map((_, index) => (
                        <FontAwesome name="star" size={16} color="#FFD700" key={index} />
                    ))}
                </View>
                <View className="my-5 flex-col gap-2">
                    <Text className="text-sm font-medium text-green-600">
                        Special Price
                    </Text>
                    <View className="flex-row gap-x-3 items-center">
                        <Text className="text-lg font-semibold">
                            ${product?.sellPrice}
                        </Text>
                        <Text className="text-sm text-gray-500 line-through">
                            ${product?.mrp}
                        </Text>
                    </View>
                    <Text className="text-gray-500 font-medium">
                        {product?.currentStock} items left
                    </Text>
                </View>
                <View className="mb-2">
                    <Text className="text-xl font-semibold my-4">Size</Text>
                    <View className="flex-row flex-wrap gap-3">
                        {sizeOptions
                            .filter((item) => product[item.value] !== 0)
                            .map((option, index) => (
                                <Pressable
                                    className={cn(
                                        "border border-gray-300 rounded-lg py-2 px-4",
                                        selectedSize === option.value &&
                                        "bg-blue-500 border-blue-500"
                                    )}
                                    key={index}
                                    onPress={() => setSelectedSize(option.value)}
                                >
                                    <Text
                                        className={cn(
                                            selectedSize === option.value &&
                                            "text-white font-medium"
                                        )}
                                    >
                                        {option.label}
                                    </Text>
                                </Pressable>
                            ))}
                    </View>
                </View>
                <View className="my-3">
                    <Text className="text-lg font-semibold">Description</Text>
                    <Text className="text-gray-600">{product?.description}</Text>
                </View>
                <View className="flex-row gap-x-4 mt-5">
                    <TouchableOpacity
                        className={cn("border border-blue-500 rounded-md py-1 px-2 w-full max-w-[160px]",
                            isProductInCart && "border-red-400"
                        )}
                        onPress={handleCartItems}
                    >
                        <Text className={cn("text-center text-lg font-semibold text-blue-500",
                            isProductInCart && "text-red-500"
                        )}>
                            {isProductInCart ? "Remove From Cart" : "Add To Cart"}
                        </Text>
                    </TouchableOpacity>
                    <TouchableOpacity className="border border-blue-500 bg-blue-500 rounded-md py-1 px-3 w-full max-w-[160px]">
                        <Text className="text-center text-lg font-semibold text-white">
                            Buy Now
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
}

export default ProductDetails;