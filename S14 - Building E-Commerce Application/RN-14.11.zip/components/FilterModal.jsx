import { Modal, Text, TouchableOpacity, View } from "react-native"

const FilterModal = ({ openFilterModal, toggleFilterModal }) => {
    return (
        <Modal
            visible={openFilterModal}
            transparent={true}
            animationType="slide"
            onRequestClose={toggleFilterModal}
        >
            <View className="h-full w-full bg-white p-10 mt-16 shadow-lg">
                <Text>Filter Modal</Text>
                <TouchableOpacity className="border border-blue-500 rounded-md py-1 px-3" onPress={toggleFilterModal}>
                    <Text className="text-center text-lg font-semibold text-blue-500">Close</Text>
                </TouchableOpacity>
            </View>
        </Modal>
    );
}

export default FilterModal;