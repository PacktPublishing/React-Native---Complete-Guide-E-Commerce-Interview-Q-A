import { Stack } from "expo-router"
import { ProductProvider } from "../components/ProductContext";
import { UserProvider } from "../components/UserContext";

export default RootLayout = () => {
    return (
        <UserProvider>
            <ProductProvider>
                <Stack>
                    <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                    <Stack.Screen
                        name="product/[id]"
                        options={{ title: "Product Details", headerBackTitle: "Back" }}
                    />
                </Stack>
            </ProductProvider>
        </UserProvider>
    );
}