import { Image, Pressable, Text, TouchableOpacity, View } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context"
import { useProductContext } from "../../components/ProductContext"
import Constants from "expo-constants"
import { FontAwesome } from "@expo/vector-icons";
import { cn } from "../../lib/utils";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const Cart = () => {
    const { cartItems, increaseQuantity, decreaseQuantity, setCartItems, removeProductFromCart, totalAmount } = useProductContext();
    const sizeOptions = [
        { label: "S", value: "smallSize" },
        { label: "M", value: "mediumSize" },
        { label: "L", value: "largeSize" },
    ]
    return (
        <SafeAreaView className="flex-1 bg-white p-8">
            <Text className="text-3xl font-semibold mb-4">Cart</Text>
            {cartItems.length > 0 ? cartItems.map((product) => (
                <View
                    className="border-b border-gray-300 py-4 flex-row gap-5"
                    key={product.id}
                >
                    <Image
                        source={{ uri: `${BASE_URL}${product?.image}` }}
                        className="w-32 h-32"
                        resizeMode="cover"
                    />
                    <View className="flex-1">
                        <View className="flex-row justify-between">
                            <Text className="text-xl font-semibold">{product?.name}</Text>
                            <Text className="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-xs font-medium">
                                {product?.productType?.name}
                            </Text>
                        </View>
                        <View className="flex-row gap-1 items-center">
                            {[...Array(product?.rating)].map((_, index) => (
                                <FontAwesome
                                    name="star"
                                    size={16}
                                    color="#FFD700"
                                    key={index}
                                />
                            ))}
                        </View>
                        <View className="flex-row gap-x-2 items-center mt-2">
                            <Text className="text-xl font-semibold">
                                ${product?.sellPrice}
                            </Text>
                            <Text className="text-gray-500 line-through font-medium text-sm">
                                ${product?.mrp}
                            </Text>
                        </View>
                        <View className="flex-row items-center gap-2 mt-2">
                            <TouchableOpacity
                                onPress={() => decreaseQuantity(product?.id)}
                                disabled={product?.quantity === 1}
                            >
                                <FontAwesome name="minus-circle" size={20} color="black" />
                            </TouchableOpacity>
                            <Text className="text-xl font-semibold">
                                {product?.quantity}
                            </Text>
                            <TouchableOpacity
                                onPress={() => increaseQuantity(product?.id)}
                                disabled={product?.quantity === product[product.size]}
                            >
                                <FontAwesome name="plus-circle" size={20} color="black" />
                            </TouchableOpacity>
                        </View>
                        <View className="flex-row justify-between items-center">
                            <View className="mb-2">
                                <Text className="text-lg font-semibold my-2">Size</Text>
                                <View className="flex-row flex-wrap gap-3">
                                    {sizeOptions
                                        .filter((item) => product[item.value] !== 0)
                                        .map((option, index) => (
                                            <Pressable
                                                className={cn(
                                                    "border border-gray-300 rounded-lg py-1 px-2",
                                                    product.size === option.value &&
                                                    "bg-blue-500 border-blue-500"
                                                )}
                                                onPress={() =>
                                                    setCartItems((prev) =>
                                                        prev.map((item) =>
                                                            product.id === item.id
                                                                ? {
                                                                    ...item,
                                                                    size: option.value,
                                                                    quantity: 1,
                                                                }
                                                                : item
                                                        )
                                                    )
                                                }
                                                key={index}
                                            >
                                                <Text
                                                    className={cn(
                                                        product.size === option.value &&
                                                        "text-white font-medium"
                                                    )}
                                                >
                                                    {option.label}
                                                </Text>
                                            </Pressable>
                                        ))}
                                </View>
                            </View>
                            <TouchableOpacity className="bg-red-500 rounded-md py-2 px-4" onPress={() => removeProductFromCart(product?.id)}>
                                <FontAwesome name="trash" size={20} color="white" />
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            )) : (
                <View className="flex-1 items-center justify-center">
                    <Text className="text-2xl font-medium"> Cart is empty.</Text>
                </View>
            )}
            {cartItems.length > 0 && (
                <View className="my-6">
                    <Text className="text-2xl font-semibold border-y border-gray-300 py-2">
                        Cart Summary
                    </Text>
                    {cartItems.map((item, index) => (
                        <View key={index} className="flex-row justify-between text-xl">
                            <Text className="text-lg font-medium">{item.name}</Text>
                            <Text className="text-lg font-medium text-end">
                                ${item.sellPrice * item.quantity}
                            </Text>
                        </View>
                    ))}
                    <View className="flex-row justify-between border-t border-gray-300 mt-3 pt-2">
                        <Text className="text-xl font-semibold">Total Amount</Text>
                        <Text className="text-xl font-semibold">${totalAmount.toFixed(2)}</Text>
                    </View>
                    <TouchableOpacity className="bg-blue-500 mt-4 py-3 rounded-xl">
                        <Text className="text-white font-semibold text-center">Checkout</Text>
                    </TouchableOpacity>
                </View>
            )}
        </SafeAreaView>
    );
}

export default Cart