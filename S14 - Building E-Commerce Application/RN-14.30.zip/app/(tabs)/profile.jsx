import { Text, TouchableOpacity, View } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context";
import { FontAwesome } from "@expo/vector-icons";
import { useUserContext } from "../../components/UserContext";
import * as SecureStore from "expo-secure-store";
import { router } from "expo-router";

const Profile = () => {
    const { userData, setUserData } = useUserContext();

    const handleLogout = async () => {
        setUserData(null);
        await SecureStore.deleteItemAsync("authToken");
        router.push("/")
    }
    return (
        <SafeAreaView className="flex-1 items-center bg-white py-20">
            <FontAwesome name="user" size={80} color="black" />
            <Text className="text-2xl font-semibold my-2">Profile</Text>
            <Text className="text-xl font-semibold my-1">{userData?.customerName}</Text>
            <Text className="text-lg font-medium"> {userData?.email}</Text>
            <TouchableOpacity className="bg-blue-600 rounded-lg py-3 px-6 mt-6" onPress={handleLogout}>
                <Text className="text-white text-center font-semibold">
                    Logout
                </Text>
            </TouchableOpacity>
        </SafeAreaView>
    )
}

export default Profile 