import { router } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Alert, Text, TextInput, TouchableOpacity, View } from "react-native"
import { SafeAreaView } from "react-native-safe-area-context";
import Constants from "expo-constants";
import * as SecureStore from "expo-secure-store";

const BASE_URL = Constants.expoConfig.extra.BASE_URL;

const Register = () => {
    const [inputData, setInputData] = useState({
        name: "",
        email: "",
        password: ""
    });
    const [loading, setLoading] = useState(false);

    const handleInputChange = (key, value) => {
        setInputData((prev) => ({ ...prev, [key]: value }));
    }

    const handleSubmit = () => {
        const { name, email, password } = inputData;

        if (!name || !email || !password) {
            Alert.alert("Error", "All fields are required.")
            return;
        }

        if (password.length < 8) {
            Alert.alert("Error", "Password must be at least 8 characters long.");
            return;
        }

        setLoading(true);

        fetch(`${BASE_URL}/api/auth/signup`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(inputData)
        })
            .then((response) => response.json())
            .then((data) => {
                SecureStore.setItem("authToken", data.token);
                console.log(data.token);
                Alert.alert("Success", "Registration successful.");
                router.push("/")
            })
            .catch((error) => console.log(error))
            .finally(() => setLoading(false));

    }
    return (
        <SafeAreaView className="flex-1 bg-white py-20">
            <Text className="text-4xl font-medium text-center">Sign Up</Text>
            <View className="w-full max-w-sm mx-auto">
                <View className="flex-col gap-6">
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Name</Text>
                        <TextInput
                            placeholder="Enter your Name"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                            onChangeText={(text) => handleInputChange("name", text)}
                            value={inputData.name}
                        />
                    </View>
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Email</Text>
                        <TextInput
                            placeholder="Enter your Email"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                            autoCapitalize="none"
                            onChangeText={(text) => handleInputChange("email", text)}
                            value={inputData.email}
                        />
                    </View>
                    <View className="flex-col gap-2">
                        <Text className="text-base font-medium text-gray-700">Password</Text>
                        <TextInput
                            placeholder="Enter your Password"
                            className="border border-gray-300 rounded-lg px-4 py-3"
                            secureTextEntry
                            onChangeText={(text) => handleInputChange("password", text)}
                            value={inputData.password}
                        />
                    </View>
                    <TouchableOpacity className="bg-blue-600 rounded-lg py-3" onPress={handleSubmit}>
                        {loading ? <ActivityIndicator /> : (
                            <Text className="text-white text-center font-semibold">
                                Submit
                            </Text>
                        )}
                    </TouchableOpacity>
                    <Text className="text-center font-medium">
                        Already have an account? <Text className="text-blue-600 font-semibold" onPress={() => router.push("/login")}>Login</Text>
                    </Text>
                </View>
            </View>
        </SafeAreaView>
    )
}

export default Register;